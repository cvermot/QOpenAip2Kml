#include<qopenaip2kmltypes.h>

TAirspaceAltitude::K_INIT = {TAirspaceAltitudeReference_UNDEF, TAltitudeUnit_UNDEF, 0};
